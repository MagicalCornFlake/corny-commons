"""A package by Konrad Guzek containing general modules that are used in various projects."""
